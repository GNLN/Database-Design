<html>
<head>
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans|Arvo|Vollkron">
</head>
<style>

h3 {
    color:  #4CAF50;
    text-align: center;
    font-family: 'Open Sans', serif;
    font-size: 25px;
}

table {
    border-collapse: collapse;
    width: 80%;
}

th{
    padding: 15px;
    text-align: left;
    font-family: 'Open Sans', serif;
    font-size: 17px;
    border-bottom: 1px solid #ddd;
}

td{
    padding: 15px;
    text-align: left;
    font-family: 'Arvo', serif;
    border-bottom: 1px solid #ddd;
}

.dropbtn {

    background-color: #4CAF50;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
    width:100%;
    font-family: 'Arvo', serif;
    
}

.dropdown {
    position: relative;
    display: inline-block;
    width:16.2%;
}

.dropdown-content {
    display: none;
    position: absolute;
    right: 0;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    font-family: 'Open Sans', serif;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    font-family: 'Open Sans', serif;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}

body{
    background-image: url(bgm.jpg);
    background-size:cover;
}
	
</style>

<body>

<h3>Rankings4U</h3>

<div class="dropdown" style>
  <a href = "#"><button class="dropbtn">About us</button></a>

</div>

<div class="dropdown">
  <a href = "#"><button class="dropbtn">Source</button></a>
  <div class="dropdown-content" style="left:0;">
    <a href="http://www.usnews.com/">US News</a>
    <a href="http://www.collegechoice.net/">College Choice</a>
    <a href="www.tfetimes.com">TFE Times</a>
    <a href="www.mastersindatascience.org">Masters in Data Science</a>
  </div>

</div>

<div class="dropdown">
  <a href = "#"><button class="dropbtn">Year</button></a>
  <div class="dropdown-content" style="left:0;">
    <a href="#">2017</a>
    <a href="#">2016</a>
    <a href="#">2015</a>
  </div>
</div>

<div class="dropdown">
  <a href = "#"><button class="dropbtn">University</button></a>
</div>

<div class="dropdown" >
  <a href = "#"><button class="dropbtn">Program</button></a>
  <div class="dropdown-content" style="left:0;">
    <a href="https://en.wikipedia.org/wiki/Master_of_Science_in_Information_Systems">MSIS</a>
    <a href="https://en.wikipedia.org/wiki/Master_of_Business_Administration">MBA</a>
    <a href="https://en.wikipedia.org/wiki/Master_of_Science_in_Business_Analytics">MSBA</a>
  </div>
</div>

<div class="dropdown" >
  <a href = "#"><button class="dropbtn">Contact us</button></a>
</div>

<br> <br> <br>

<div align = 'center'>
<table>
<tr>

<th>Year</th>
<th>Source</th>
<th>University</th>
<th>Program</th>
<th>Rank</th>
<th>Weighted Rank</th>
</tr>

<?php

$user = 'root';
$pass = '';
#$db = 'rankings4u';
$link = mysql_connect('localhost', $user, $pass);
mysql_select_db('rankings4u', $link);
if (isset($_POST['search_btn'])) {
	$sName = ($_POST['source']);
    #echo $sName[0];
    $sname_ids = join("','", $sName);
    #echo $ids;
  	$year = $_POST['year'];
    $year_ids = join("','", $year);
  	$university_ids = $_POST['university'];
  	$program =$_POST['program'];
    $program_ids = join("','", $program);
    if(isset($_POST['top5'])){
         $run = mysql_query("SELECT * FROM gives WHERE (sName IN ('$sname_ids')) AND (year IN ('$year_ids')) AND (pName IN ('$program_ids')) ORDER BY year DESC, pName, rank, weightedRank LIMIT 5") ;
    }

     elseif(isset($_POST['uview'])){
        #$run = mysql_query("SELECT * FROM gives WHERE rank<= (SELECT rank FROM gives where uniName IN ('$university_ids')) AND (sName IN('$sname_ids')) AND (year IN ('$year_ids')) AND (pName IN('$program_ids')) ORDER BY year DESC, pName, weightedRank DESC, rank");
     $try= mysql_query("SELECT MAX(rank) FROM gives where uniName IN ('$university_ids') AND (sName IN('$sname_ids')) AND (year IN ('$year_ids')) AND (pName IN('$program_ids'))");
	 $var = mysql_fetch_array($try);
	 $run = mysql_query("SELECT * FROM gives WHERE rank<= $var[0] AND (sName IN('$sname_ids')) AND (year IN ('$year_ids')) AND (pName IN('$program_ids')) ORDER BY sName, year DESC, pName,rank, weightedRank DESC");
	 }
 
     else{
        if($university_ids == "*"){


        $run = mysql_query("SELECT * FROM gives WHERE (sName IN ('$sname_ids')) AND (year IN ('$year_ids')) AND (pName IN ('$program_ids')) ORDER BY year DESC, pName, weightedRank DESC, rank");
     
     }
     else{
        $run = mysql_query("SELECT * FROM gives WHERE (sName IN ('$sname_ids')) AND (year IN ('$year_ids')) AND (pName IN ('$program_ids')) AND (uniName in ('$university_ids')) ORDER BY year DESC, pName, weightedRank DESC, rank");
     }
 }

    #echo $run;
    while ($row = mysql_fetch_array($run)) {
		
    	#$rankid = $row[0];
    	$year = $row[1];
    	$sname = $row[2];
    	$uniname = $row[3];
    	$pname = $row[4];
    	$rank = $row[5];
    	$weightedrank = $row[6];
		
    	# code...
    	echo "<tr>
    			
    			<td>$year</td>
    			<td>$sname</td>
    			<td> <a href = 'use1.html'>$uniname</td>
    			<td>$pname </td>
    			<td>$rank</td>
    			<td>$weightedrank</td>
    		</tr>";
    }
  }
if (isset($_POST['submit_btn'])) {
	
  	$program =$_POST['program'];
    $program_ids = join("','", $program);
	$region =$_POST['region'];
         $run = mysql_query("SELECT g.year, g.sName, g.uniName, g.pName, g.rank, g.weightedRank FROM gives g, university u WHERE (g.uniName = u.uniName) AND u.uLocation IN ('$region') AND g.pName IN ('$program_ids')" );
    
    #echo $run;
    while ($row = mysql_fetch_array($run)) {
    	#$rankid = $row[0];
    	$year = $row[0];
    	$sname = $row[1];
    	$uniname = $row[2];
    	$pname = $row[3];
    	$rank = $row[4];
    	$weightedrank = $row[5];
    	# code...
    	echo "<tr>
    			
    			<td>$year</td>
    			<td>$sname</td>
    			<td> <a href = 'use1.html'>$uniname</td>
    			<td>$pname </td>
    			<td>$rank</td>
    			<td>$weightedrank</td>
    		</tr>";
    }
  }
if (isset($_POST['cost_btn'])) {
	
  	$program =$_POST['program'];
    $program_ids = join("','", $program);
	$mincost =$_POST['mincost'];
	$maxcost =$_POST['maxcost'];
         $run = mysql_query("SELECT g.year, g.sName, g.uniName, g.pName, g.rank, g.weightedRank, u.pCost FROM gives g, offers u WHERE (g.uniName = u.uniName) AND u.pCost >= $mincost AND u.pCost <= $maxcost AND g.pName IN ('$program_ids')" );
    
    #echo $run;
    while ($row = mysql_fetch_array($run)) {
    	#$rankid = $row[0];
    	$year = $row[0];
    	$sname = $row[1];
    	$uniname = $row[2];
    	$pname = $row[3];
    	$rank = $row[4];
    	$weightedrank = $row[5];
		$pcost= $row[6];
    	# code...
    	echo "<tr>
    			
    			<td>$year</td>
    			<td>$sname</td>
    			<td> <a href = 'use1.html'>$uniname</td>
    			<td>$pname </td>
    			<td>$rank</td>
    			<td>$weightedrank</td>
				<td> $pcost </td>
    		</tr>";
    }
  }


?>
</table>

</div>
</body>
</html>